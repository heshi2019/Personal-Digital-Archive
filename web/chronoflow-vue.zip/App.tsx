// This file is deprecated. The application entry point is now managed via index.tsx using Vue 3.
export default function App() {
  return null;
}