export interface TimelineEvent {
  id: string;
  date: string;
  title: string;
  description: string;
  category: 'mission' | 'discovery' | 'technology';
  icon?: string;
  imageUrl?: string;
}

export interface TimelineProps {
  events: TimelineEvent[];
}