// Deprecated. Data generation is now handled within index.html script.
export const SPACE_HISTORY_EVENTS = [];